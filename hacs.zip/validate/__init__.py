"""Initialize validation."""
