"""JSON utils."""

from homeassistant.util.json import json_loads

__all__ = ["json_loads"]
